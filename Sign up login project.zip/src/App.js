import Dashboard from './Adminpenal/Dashboard';
import './App.css';

import Loginin from './component/Loginin';
import Loginlist from './component/Loginlist';
import Signup from './component/Signup';
import Signuplist from './component/Signuplist';
import { BrowserRouter as Router, Route, Switch } from 'react-router-dom';


function App() {
  return (
   <Router>
    <Switch>
    <Route exact  path="/">
        <Signup />
        {/* <Signuplist /> */}

      </Route>
      <Route exact  path="/signup">
        <Signup />
        {/* <Signuplist /> */}

      </Route>

      <Route exact path="/loginin">
        <Loginin />
        {/* <Loginlist /> */}

      </Route>
      <Route exact path="/dashboard">
        <Dashboard />
        {/* <Loginlist /> */}

      </Route>


    </Switch>
   </Router>

   
  
  );
}

export default App;
