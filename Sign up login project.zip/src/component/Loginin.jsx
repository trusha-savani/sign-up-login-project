import React, { useEffect } from 'react';
import { Formik, Form, Field, ErrorMessage } from 'formik';
import * as Yup from "yup";
import { useDispatch, useSelector } from 'react-redux';
import { login } from '../features/counter/counterSlice';
import { useHistory } from 'react-router-dom';
import { Box, Typography, Grid, TextField, Button } from '@mui/material';
import 'aos/dist/aos.css';
import AOS from 'aos';
import { Bounce, ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import RotateLeftIcon from '@mui/icons-material/RotateLeft';
import ExitToAppIcon from '@mui/icons-material/ExitToApp';

const TEST_SCHEMA = Yup.object().shape({
    email: Yup.string().email('INVALID EMAIL').required('IS REQUIRED !'),
    password: Yup.string().required('No password provided.').min(8, 'Password is too short - should be 8 chars minimum.'),
});

const tostify = (msg) => {
    toast(msg, {
        position: "top-right",
        autoClose: 1000,
        hideProgressBar: false,
        closeOnClick: true,
        pauseOnHover: true,
        draggable: true,
        progress: undefined,
        theme: "dark",
        transition: Bounce,
    });
}

const interests = ['Comic Books', 'Sports', 'Makeup'];

function Loginin() {
    const dispatch = useDispatch();
    const history = useHistory();
    const data = useSelector((state) => state.counter.loginInitialValues);
    const id = useSelector((state) => state.counter.id);

    useEffect(() => {
        AOS.init();
    }, [])

    return (
        <Box className='back' height={{ xl: '100vh', md: 'auto', sm: 'auto', xs: 'auto' }} sx={{ position: 'relative', minHeight: '100vh', display: 'flex', alignItems: 'center', justifyContent: 'center' }} >
            <Box sx={{
                position: 'absolute',
                top: 0,
                left: 0,
                right: 0,
                bottom: 0,
                backgroundImage: 'url(https://img.freepik.com/free-photo/female-hand-typing-keyboard-laptop_1150-15742.jpg?t=st=1718163798~exp=1718167398~hmac=e609997fc31d489082cacef828159262609d9dc74a66224ea35d6823bb66e17c&w=740)',
                backgroundSize: 'cover',
                backgroundPosition: 'center',
                zIndex: 1,
                '::before': {
                    content: '""',
                    position: 'absolute',
                    top: 0,
                    left: 0,
                    right: 0,
                    bottom: 0,
                    backgroundColor: 'rgb(35 35 35 / 69%)',
                    zIndex: 2,
                }
            }}>
            </Box>
            <Grid container className="head" sx={{ zIndex: 3 }} >
                <Grid item xs={12} sm={6} md={5} sx={{ mt: -3, display: 'flex', justifyContent: 'center' }} data-aos="fade-in">
                    <Box sx={{ backgroundColor: '#fff', height: '300px', width: '100%', borderRadius: '8px', boxShadow: 3, padding: '20px 40px 40px 40px ' }} >
                        <Formik
                            initialValues={data}
                            enableReinitialize
                            validationSchema={TEST_SCHEMA}
                            onSubmit={async (values, action) => {
                                dispatch(login(values));
                               
                                action.resetForm();
                     
                                // history.push('/dashboard');
                            }}
                        >
                            <Form className='box'>
                                <Box className="set">
                                    <Typography variant='h4' sx={{ textAlign: 'center', color: 'black',fontWeight:'700' }}>LOGIN</Typography>
                                </Box>

                                <Box sx={{ mt: 2, color: 'black', fontWeight: '600' }}>
                                    <label htmlFor="email">E - MAIL <ErrorMessage name='email' component={'span'} className='Error' /> </label>
                                    <Field as={TextField} variant="filled" fullWidth id="email" name="email" placeholder="ENTER VALID EMAIL" type="email" />
                                </Box>
                                <Box sx={{ mt: 2, color: 'black', fontWeight: '600' }}>
                                    <label htmlFor="password">PASSWORD <ErrorMessage name='password' component={'span'} className='Error' /> </label>
                                    <Field as={TextField} variant="filled" fullWidth id="password" name="password" placeholder="ENTER VALID PASSWORD" type="password" />
                                </Box>

                                <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', mt: 8 ,flexDirection: { xs: 'column', sm: 'row' } }}  >
                                <Button type="reset" variant="contained" sx={{color:'white',width:'47%',backgroundColor:'black',":hover":{backgroundColor:'red'},mx:1}} endIcon={<RotateLeftIcon />} >RESET</Button>
                                    <Button type="submit" variant="contained" sx={{color:'white',width:'47%',backgroundColor:'black',":hover":{backgroundColor:'red'}}}  endIcon={<ExitToAppIcon />}>Sign Up</Button>
                                </Box>
                            </Form>
                        </Formik>
                    </Box>
                </Grid>
            </Grid>
            <ToastContainer
                position="top-right"
                autoClose={1000}
                hideProgressBar={false}
                newestOnTop={false}
                closeOnClick
                rtl={false}
                pauseOnFocusLoss
                draggable
                pauseOnHover
                theme="dark"
                transition={Bounce}
            />
        </Box>
    );
}

export default Loginin;




