import React from 'react';
import {  useSelector } from 'react-redux';


function Loginlist() {

    let DATA = useSelector((state) => state.counter.fromData);
   

    return (
        <div>
            <table border={2} cellPadding={10} width={"100%"} style={{ marginTop: "60px" }}>
                <tr>
                    <th> INDEX </th>
                    <th> FIRST NAME </th>
                    <th> LAST NAME </th>
                    <th> E - MAIL </th>
                    <th> PASSWORD </th>
                    <th> repeatpassword </th>
                    <th>  INTERESTS</th>
                    <th> MAILINGLIST </th>
                    <th> COMMENTS </th>

                    
                </tr>
                {
                    DATA.map((el, index) => {
                        return (
                            <tr key={index}>
                                <td> {index + 1} </td>
                                <td> {el.firstName} </td>
                                <td> {el.lastName} </td>
                                <td> {el.email} </td>
                                <td> {el.password} </td>
                                <td> {el.repeatpassword} </td>
                                <td> {el.interest} </td>
                                <td> {el.mailinglist} </td>
                                <td> {el.comments} </td>
                                
                            </tr>
                        )
                    })
                }
            </table>
        </div>
    )
}

export default Loginlist;
