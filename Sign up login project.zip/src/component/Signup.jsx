import React, { useEffect } from 'react';
import { Formik, Form, Field, ErrorMessage } from 'formik';
import * as Yup from "yup";
import { useDispatch, useSelector } from 'react-redux';
import { AddData } from '../features/counter/counterSlice';
import { useHistory } from 'react-router-dom';
import { Box, Typography, Grid, TextField, Button,FormControlLabel,RadioGroup,Radio } from '@mui/material';
import 'aos/dist/aos.css';
import AOS from 'aos';
import Checkbox from '@mui/material/Checkbox';
import RotateLeftIcon from '@mui/icons-material/RotateLeft';
import ExitToAppIcon from '@mui/icons-material/ExitToApp';

const TEST_SCHEMA = Yup.object().shape({
    firstName: Yup.string().min(2, 'TOO SHORT !').max(50, 'TOO LONG !').required('IS REQUIRED !'),
    lastName: Yup.string().min(2, 'TOO SHORT !').max(50, 'TOO LONG !').required('IS REQUIRED !'),
    email: Yup.string().email('INVALID EMAIL').required('IS REQUIRED !'),
    password: Yup.string().required('NOT VALID PASSWORD .').min(8, 'Password is too short - should be 8 chars minimum.'),
    repeatpassword: Yup.string().oneOf([Yup.ref('password'), null], 'Passwords must match').required('IS REQUIRED !'),
    interest: Yup.array().min(1, 'IS REQUIRED !').required('IS REQUIRED !'),
    mailinglist: Yup.string().required('IS REQUIRED !'),
    comments: Yup.string().required('IS REQUIRED !'),
});

const interests = ['Comic Books', 'Sports', 'Makeup'];

function Signup() {
    const dispatch = useDispatch();
    const history = useHistory();
    const data = useSelector((state) => state.counter.setInitialValues);
    const id = useSelector((state) => state.counter.id);

    useEffect(()=>{
        AOS.init();
    },[])


    return (
        <Box className='back' height={{xl:'100vh',md:'auto',sm:'auto',xs:'auto'}} sx={{ position: 'relative', minHeight: '100vh', display: 'flex', alignItems: 'center', justifyContent: 'center' }} >
            <Box sx={{
                position: 'absolute',
                top: 0,
                left: 0,
                right: 0,
                bottom: 0,
                backgroundImage: 'url(https://img.freepik.com/free-photo/female-hand-typing-keyboard-laptop_1150-15742.jpg?t=st=1718163798~exp=1718167398~hmac=e609997fc31d489082cacef828159262609d9dc74a66224ea35d6823bb66e17c&w=740)',
                backgroundSize: 'cover',
                backgroundPosition: 'center',
                zIndex: 1,
                '::before': {
                    content: '""',
                    position: 'absolute',
                    top: 0,
                    left: 0,
                    right: 0,
                    bottom: 0,
                    backgroundColor: 'rgb(35 35 35 / 69%)',
                    zIndex: 2,
                }
            }}>
            </Box>
            <Grid container className="head" sx={{ zIndex: 3 }} >
                <Grid item xs={12} sm={6} md={5} sx={{ mt:-2, display: 'flex', justifyContent: 'center' }} >
                    <Box sx={{ backgroundColor: '#fff', height: '710px', width: '100%', borderRadius: '8px', boxShadow: 3, padding:'20px 40px 40px 40px '}} data-aos="fade-up" height={{xl:'750px',md:'750px',xs:'850px',sm:'800px'}}>
                        <Formik
                            initialValues={data}
                            enableReinitialize
                            validationSchema={TEST_SCHEMA}
                            onSubmit={async (values, action) => {
                                dispatch(AddData(values));
                               
                                action.resetForm();
                                alert('User registration successfully ');
                                history.push('/loginin');
                            }}
                        >
                            <Form className='box'>
                                <Box className="set">
                                    <Typography variant='h4' sx={{ textAlign: 'center',color:'black',fontWeight:'700' }}>SIGN UP</Typography>
                                </Box>
                                <Box sx={{color:'black',fontWeight:'600'}}>
                                    <label htmlFor="firstName" sx={{color:'white'}}>FIRST NAME <ErrorMessage name='firstName' component={'span'} className='Error' /></label>
                                    <Field as={TextField}  variant="filled" fullWidth id="firstName" name="firstName" placeholder="ENTER FIRST NAME" />
                                    
                                </Box>
                                <Box sx={{ color:'black',fontWeight:'600' }}>
                                    <label htmlFor="lastName">LAST NAME <ErrorMessage name='lastName' component={'span'} className='Error' /> </label>
                                    <Field as={TextField} variant="filled" fullWidth id="lastName" name="lastName" placeholder="ENTER LAST NAME" />
                                    
                                </Box>
                                <Box sx={{ color:'black',fontWeight:'600',backgroundColor:'transparent' }}>
                                    <label htmlFor="email">E - MAIL <ErrorMessage name='email' component={'span'} className='Error' /> </label>
                                    <Field as={TextField} variant="filled" fullWidth id="email" name="email" placeholder="ENTER VALID EMAIL" type="email" />
                                    
                                </Box>
                                <Box sx={{color:'black',fontWeight:'600' }}>
                                    <label htmlFor="password">PASSWORD  <ErrorMessage name='password' component={'span'} className='Error' /></label>
                                    <Field as={TextField} variant="filled" fullWidth id="password" name="password" placeholder="ENTER VALID PASSWORD" type="password" />
                                    
                                </Box>
                                <Box sx={{ color:'black',fontWeight:'600' }}>
                                    <label htmlFor="repeatpassword">REPEAT PASSWORD<ErrorMessage name='repeatpassword' component={'span'} className='Error' /> </label>
                                    <Field as={TextField} sx={{color:'grey'}} variant="filled" fullWidth id="repeatpassword" name="repeatpassword" placeholder="REPEAT PASSWORD" type="password" />
                                    
                                </Box>
                               
                                <Box  >
                                    <Typography variant='subtitle1' sx={{fontWeight:'600'}}>What are your interests? <ErrorMessage name='interest' component='div' className='Error' /></Typography>
                                    <Box role="group" aria-labelledby="checkbox-group">
                                        {interests.map((interest, index) => (
                                            <FormControlLabel
                                                key={index}
                                                control={<Field type="checkbox" as={Checkbox} name="interest" value={interest} />}
                                                label={interest}
                                            />
                                        ))}
                                    </Box>
                                    
                                </Box>
                                
                                 <Box sx={{ display:'flex',alignItems:'center',}}>
                                    <Typography sx={{fontSize:'16px',fontWeight:'600'}} >Join our mailing list?</Typography>
                                    <RadioGroup row aria-labelledby="mailinglist-group" name="mailinglist" >
                                        <FormControlLabel  sx={{marginLeft:'30px'}}
                                            control={<Field type="radio" as={Radio} name="mailinglist" value="yes" />} 
                                            label="Yes" 
                                        />
                                        <FormControlLabel sx={{marginLeft:'30px'}} 
                                            control={<Field type="radio" as={Radio} name="mailinglist" value="no" />} 
                                            label="No" 
                                        />
                                    </RadioGroup>
                                </Box>
                                    <ErrorMessage name='mailinglist' component='div' className='Error' />
                                <Box sx={{ mt: 0,fontWeight:'700' }}>
                                    <label htmlFor="comments">COMMENTS <ErrorMessage name='comments' component={'span'} className='Error' /></label>
                                    <Field as={TextField}  fullWidth id="comments" name="comments" placeholder="ENTER YOUR COMMENTS" multiline rows={3} />
                                </Box>
                                <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', mt: 8 ,flexDirection: { xs: 'column', sm: 'row' },gap:1 }}  >
                                <Button type="reset" variant="contained" sx={{color:'white',width:'47%',backgroundColor:'black',":hover":{backgroundColor:'red'},mx:1}}endIcon={<RotateLeftIcon />} >RESET</Button>
                                    <Button type="submit" variant="contained" sx={{color:'white',width:'47%',backgroundColor:'black',":hover":{backgroundColor:'red'}}}  endIcon={<ExitToAppIcon />}>Sign Up</Button>
                                </Box>
                                 
                            </Form>
                        </Formik>
                    </Box>
                </Grid>
            </Grid>
      
        </Box>
    );
}

export default Signup;


 


