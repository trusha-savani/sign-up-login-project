import { createSlice } from '@reduxjs/toolkit';
import { toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';

export const counterSlice = createSlice({
    name: 'counter',
    initialState: {
        value: 0,
        fromData: [{ firstName: "TRUSHA", lastName: "SAVANI", email: "TRUSHA@GMAIL.COM", password: '12345678', repeatpassword: '12345678', interest: 'makeup', mailinglist: 'yes', comments: 'abcd' },{ firstName: "YANA", lastName: "SAVANI", email: "YANA@GMAIL.COM", password: '12345678', repeatpassword: '12345678', interest: 'makeup', mailinglist: 'yes', comments: 'abcd' }],
        setInitialValues: { firstName: '', lastName: '', email: '', password: '', repeatpassword: '', interest: '', mailinglist: '', comments: '' },
        loginInitialValues: { email: '', password: '' },
        id: null,
     
    },
    reducers: {
        AddData: (state, action) => {
            state.fromData.push(action.payload);
            localStorage.setItem('fromData', JSON.stringify(state.fromData));
        },
        login: (state, action) => {
            const { email, password } = action.payload;
            const storedData = JSON.parse(localStorage.getItem('fromData'));
        
            const user = storedData.find(
                (userData) => userData.email === email && userData.password === password
            );
           if (user) {
                toast.success("Login successful");
                state.currentUser = user;
            } else {
                toast.error("Invalid email password");
            }
        },
        logout: (state) => {
            state.currentUser = null;
        },
    },
});
export const { AddData, login, logout } = counterSlice.actions;

export default counterSlice.reducer;
